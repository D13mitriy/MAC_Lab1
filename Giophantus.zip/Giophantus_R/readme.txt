.
├── KAT
│   └── encrypt
│       ├── IEC1134
│       │   ├── PQCencryptKAT_1134.req
│       │   ├── PQCencryptKAT_1134.rsp
│       │   └── intermediate.txt
│       ├── IEC602
│       │   ├── PQCencryptKAT_602.req
│       │   ├── PQCencryptKAT_602.rsp
│       │   └── intermediate.txt
│       └── IEC868
│           ├── PQCencryptKAT_868.req
│           ├── PQCencryptKAT_868.rsp
│           └── intermediate.txt
├── Optimized_Implementation
│   └── encrypt
│       ├── IEC1134
│       │   ├── Makefile
│       │   ├── PQCgenKAT_encrypt.c
│       │   ├── aes256.c
│       │   ├── api.h
│       │   ├── benchmark.c
│       │   ├── genrand.c
│       │   ├── genrand.h
│       │   ├── iec.c
│       │   ├── iec.h
│       │   ├── intermediate-iec.c
│       │   ├── intermediate-main.c
│       │   ├── parameter.h
│       │   ├── poly.c
│       │   ├── polyopt.c
│       │   ├── rng.c
│       │   ├── rng.h
│       │   ├── sample.c
│       │   ├── seedexpand.c
│       │   ├── seedexpand.h
│       │   ├── sha3.c
│       │   └── sha3.h
│       ├── IEC602
│       │   ├── Makefile
│       │   ├── PQCgenKAT_encrypt.c
│       │   ├── aes256.c
│       │   ├── api.h
│       │   ├── benchmark.c
│       │   ├── genrand.c
│       │   ├── genrand.h
│       │   ├── iec.c
│       │   ├── iec.h
│       │   ├── intermediate-iec.c
│       │   ├── intermediate-main.c
│       │   ├── parameter.h
│       │   ├── poly.c
│       │   ├── polyopt.c
│       │   ├── rng.c
│       │   ├── rng.h
│       │   ├── sample.c
│       │   ├── seedexpand.c
│       │   ├── seedexpand.h
│       │   ├── sha3.c
│       │   └── sha3.h
│       ├── IEC868
│       │   ├── Makefile
│       │   ├── PQCgenKAT_encrypt.c
│       │   ├── aes256.c
│       │   ├── api.h
│       │   ├── benchmark.c
│       │   ├── genrand.c
│       │   ├── genrand.h
│       │   ├── iec.c
│       │   ├── iec.h
│       │   ├── intermediate-iec.c
│       │   ├── intermediate-main.c
│       │   ├── parameter.h
│       │   ├── poly.c
│       │   ├── polyopt.c
│       │   ├── rng.c
│       │   ├── rng.h
│       │   ├── sample.c
│       │   ├── seedexpand.c
│       │   ├── seedexpand.h
│       │   ├── sha3.c
│       │   └── sha3.h
│       └── Makefile
├── Reference_Implementation
│   └── encrypt
│       ├── IEC1134
│       │   ├── Makefile
│       │   ├── PQCgenKAT_encrypt.c
│       │   ├── aes256.c
│       │   ├── api.h
│       │   ├── benchmark.c
│       │   ├── genrand.c
│       │   ├── genrand.h
│       │   ├── iec.c
│       │   ├── iec.h
│       │   ├── intermediate-iec.c
│       │   ├── intermediate-main.c
│       │   ├── parameter.h
│       │   ├── poly.c
│       │   ├── polyopt.c
│       │   ├── rng.c
│       │   ├── rng.h
│       │   ├── sample.c
│       │   ├── seedexpand.c
│       │   ├── seedexpand.h
│       │   ├── sha3.c
│       │   └── sha3.h
│       ├── IEC602
│       │   ├── Makefile
│       │   ├── PQCgenKAT_encrypt.c
│       │   ├── aes256.c
│       │   ├── api.h
│       │   ├── benchmark.c
│       │   ├── genrand.c
│       │   ├── genrand.h
│       │   ├── iec.c
│       │   ├── iec.h
│       │   ├── intermediate-iec.c
│       │   ├── intermediate-main.c
│       │   ├── parameter.h
│       │   ├── poly.c
│       │   ├── polyopt.c
│       │   ├── rng.c
│       │   ├── rng.h
│       │   ├── sample.c
│       │   ├── seedexpand.c
│       │   ├── seedexpand.h
│       │   ├── sha3.c
│       │   └── sha3.h
│       ├── IEC868
│       │   ├── Makefile
│       │   ├── PQCgenKAT_encrypt.c
│       │   ├── aes256.c
│       │   ├── api.h
│       │   ├── benchmark.c
│       │   ├── genrand.c
│       │   ├── genrand.h
│       │   ├── iec.c
│       │   ├── iec.h
│       │   ├── intermediate-iec.c
│       │   ├── intermediate-main.c
│       │   ├── parameter.h
│       │   ├── poly.c
│       │   ├── polyopt.c
│       │   ├── rng.c
│       │   ├── rng.h
│       │   ├── sample.c
│       │   ├── seedexpand.c
│       │   ├── seedexpand.h
│       │   ├── sha3.c
│       │   └── sha3.h
│       └── Makefile
└── Supporting_Documentation
   │
   ├── Proposal(NIST_PQC)Giophantus_final.pdf
   ├── Imprementation Memo.pdf
